package debug;


import com.icarbonx.smart.common.base.BaseApplication;

public class DebugApplication extends BaseApplication {
    @Override
    public void onCreate() {
        super.onCreate();
        login();
    }

    private void login() {
        //做些事情
    }
}
