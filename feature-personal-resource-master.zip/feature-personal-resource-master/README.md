	引用lib-common工程下lib_common组件
	/maven下引用 implementation 'com.icarbonx.smart:common:0.0.2'

	### 模板组件功能（业务组件）：
	1. 

	
	注意：
	1. 路由跳转的组名是组件名，比如@Route(path="/module_template/other")
	2. 组件的主包名为com.icarbonx.living.module_template,module_template为当前组件名


## License

    Copyright 2017 guiying712, AndroidModulePattern Open Source Project

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
