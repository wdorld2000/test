package com.lost.zou.scaleruler;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.lost.zou.scaleruler.utils.DrawUtil;
import com.lost.zou.scaleruler.view.DecimalScaleRulerView;
import com.lost.zou.scaleruler.view.ScaleRulerView;

/**
 * Created by zoubo on 16/3/16.
 * 横向滚动刻度尺测试类
 */

public class MainActivity extends AppCompatActivity {

    ScaleRulerView mHeightWheelView;
    TextView mHeightValue;
    ScaleRulerView mWeightWheelView;
    TextView mWeightValue;
    DecimalScaleRulerView mWeightRulerView;
    TextView mWeightValueTwo;
    Button mButton;

    private float mHeight = 170;
    private float mMaxHeight = 220;
    private float mMinHeight = 100;

    private float mWeight = 60.0f;
    private float mMaxWeight = 200;
    private float mMinWeight = 25;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mHeightWheelView = (ScaleRulerView)findViewById(R.id.scaleWheelView_height);
        mHeightValue = (TextView)findViewById(R.id.tv_user_height_value);
        mWeightWheelView = (ScaleRulerView)findViewById(R.id.scaleWheelView_weight);
        mWeightValue = (TextView)findViewById(R.id.tv_user_weight_value);
        mWeightRulerView = (DecimalScaleRulerView)findViewById(R.id.ruler_weight);
        mWeightValueTwo = (TextView)findViewById(R.id.tv_user_weight_value_two);
        mButton = (Button)findViewById(R.id.btn_choose_result) ;

        init();

        mButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String msg = "选择身高： " + mHeight + " 体重： " + mWeight;
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });

    }

    private void init() {
        mHeightValue.setText((int) mHeight + "");
        mWeightValue.setText(mWeight + "");
        mWeightValueTwo.setText(mWeight + "kg");


        mHeightWheelView.initViewParam(mHeight, mMaxHeight, mMinHeight);
        mHeightWheelView.setValueChangeListener(new ScaleRulerView.OnValueChangeListener() {
            @Override
            public void onValueChange(float value) {
                mHeightValue.setText((int) value + "");
                mHeight = value;
            }
        });

        mWeightWheelView.initViewParam(mWeight, mMaxWeight, mMinWeight);
        mWeightWheelView.setValueChangeListener(new ScaleRulerView.OnValueChangeListener() {
            @Override
            public void onValueChange(float value) {
                mWeightValue.setText(value + "");
                mWeight = value;
            }
        });


        mWeightRulerView.setParam(DrawUtil.dip2px(10), DrawUtil.dip2px(32), DrawUtil.dip2px(24),
                DrawUtil.dip2px(14), DrawUtil.dip2px(9), DrawUtil.dip2px(12));
        mWeightRulerView.initViewParam(mWeight, 20.0f, 200.0f, 1);
        mWeightRulerView.setValueChangeListener(new DecimalScaleRulerView.OnValueChangeListener() {
            @Override
            public void onValueChange(float value) {
                mWeightValueTwo.setText(value + "kg");

                mWeight = value;
            }
        });
    }

}
